const products = [
    {
        name: 'Bugatti Chiron',
        price: 50000,
        img: 'https://cdn.sanity.io/images/vxy259ii/production/5cb386c3d69fedf34d1a328381db32689c22ed5a-1700x913.jpg?auto=format&crop=entropy&fit=crop&h=810&q=80&w=1440',
        brand: 'Bugatti'
    },
    {
        name: 'Lamborghini Urus',
        price: 70000,
        img: 'https://i.blogs.es/e6b32c/urus1/1366_2000.jpg',
        brand: 'Lamborghini'
    },
    {
        name: 'Rolls Royce Phantom',
        price: 60000,
        img: 'https://hips.hearstapps.com/hmg-prod/images/rolls-royce-phantom-tuned-by-spofec-3-1577188216.jpg',
        brand: 'Rolls Royce'
    },
    {
        name: 'Mercedes Benz S class',
        price: 50000,
        img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDdmWwhUS6YOvd8se-QPg0FPL5DdarRvKEKw&s',
        brand: 'Mercedes Benz'
    },
    {
        name: 'Cybertruck',
        price: 30000,
        img: 'https://imagenes.autobild.es/files/image_640_360/uploads/imagenes/2023/10/03/68ca6fcdd5ac9.jpeg',
        brand: 'Tesla'
    },
];

let cart = [];

const productsContainer = document.getElementById('products');
const shoppingCart = document.getElementById('shopping-cart');
const amountCart = document.getElementById('amount-cart');
const totalCart = document.getElementById('total-cart');

showProducts();

// array.map()
// const arr = [1,2,3,4];

// const doble = arr.map(n => {
//     return n*2;
// })

// console.log(doble);

const buttonsAdd = document.querySelectorAll('.add-cart');

buttonsAdd.forEach(button => {
    button.addEventListener('click', () => {
        const card = button.parentElement;
        
        const productName = card.querySelector('.product-name').textContent;
        
        const productSelected = products.find(product => product.name === productName);

        productSelected.quantity = 1;

        const productExists = cart.find(product => product.name === productName);

        if(productExists){
            alert('this product is already added');
            return;
        }

        cart.push(productSelected);

        renderCart(cart);

    });
        
});

// -------------------

function showProducts(){

    for(let i = 0; i < products.length; i++){

        const product = products[i];

        const card = document.createElement('div');
        card.innerHTML = `
        <div class="bg-white border border-gray-200 rounded-xl p-3 flex flex-col gap-2">
            <div class="text-4xl h-auto flex items-center justify-center bg-gray-50 rounded-lg">
                <img src="${product.img}" alt="">
            </div>
            <div class="text-sm font-medium text-gray-800 product-name">${product.name}</div>
            <div class="text-xs text-gray-400">${product.brand}</div>
            <div class="text-base font-semibold text-gray-800">$${product.price.toLocaleString()}</div>
            <button class="text-xs py-1.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 transition add-cart">
              + Agregar
            </button>
          </div>`;

        productsContainer.appendChild(card);

        // productsContainer.innerHTML += `
        // <div class="bg-white border border-gray-200 rounded-xl p-3 flex flex-col gap-2">
        //     <div class="text-4xl h-auto flex items-center justify-center bg-gray-50 rounded-lg">
        //         <img src="${product.img}" alt="">
        //     </div>
        //     <div class="text-sm font-medium text-gray-800">${product.name}</div>
        //     <div class="text-xs text-gray-400">${product.brand}</div>
        //     <div class="text-base font-semibold text-gray-800">${product.price}</div>
        //     <button class="text-xs py-1.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 transition">
        //       + Agregar
        //     </button>
        //   </div>`;

    }

}

function renderCart(cart){
    amountCart.textContent = cart.length;

        // let total = 0;
        // for(let i = 0; i < cart.length; i++){
        //     total += cart[i].price;
        // }

    const total = cart.reduce((acum, product) => acum + (product.price * product.quantity), 0);

    totalCart.textContent = `$${total.toLocaleString()}`;

    shoppingCart.innerHTML = '';

    for(let i = 0; i < cart.length; i++){

        const product = cart[i];

        shoppingCart.innerHTML += `<div class="flex items-center gap-2 py-2 border-b border-gray-100">
            <div class="text-xl w-9 h-9 flex items-center justify-center bg-gray-50 rounded-lg shrink-0">
            <img src="${product.img}">
            </div>
            <div class="flex-1 min-w-0">
            <div class="text-xs font-medium text-gray-800 truncate">${product.name}</div>
            <div class="text-xs text-gray-400">$${product.price}</div>
            <div class="flex items-center gap-1 mt-1">
                <button class="w-5 h-5 text-sm border border-gray-200 rounded bg-gray-50 text-gray-700 hover:bg-gray-100" onclick="changeQuantity('${product.name}', '-')">−</button>
                <span class="text-xs font-medium w-4 text-center text-gray-800">${product.quantity}</span>
                <button class="w-5 h-5 text-sm border border-gray-200 rounded bg-gray-50 text-gray-700 hover:bg-gray-100" onclick="changeQuantity('${product.name}', '+')">+</button>
            </div>
            </div>
            <button class="text-gray-300 hover:text-red-400 text-lg leading-none" onclick='removeProduct(${JSON.stringify(product)})'>×</button>
        </div>`;

    }

}

function removeProduct(product){

    cart = cart.filter(productCart => productCart.name !== product.name)
    
    renderCart(cart);

}

function changeQuantity(name, op){

    cart = cart.map((product) => {
        if(product.name === name){
            if(op === '+'){
                product.quantity++;
            }else{
                product.quantity--;
            }
        }

        return product;
    });

    const productEmpty = cart.find(product => product.quantity === 0);

    if(productEmpty){
        removeProduct(productEmpty);
        return;
    }


    renderCart(cart);

}